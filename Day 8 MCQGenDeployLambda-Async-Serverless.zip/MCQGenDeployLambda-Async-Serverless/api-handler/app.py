import json
import boto3
import os

def lambda_handler(event, context):
    # Parse input
    try:
        request_body = json.loads(event.get('body', '{}'))
    except:
        request_body = event
    
    # Immediately respond
    response = {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps({
            'status': 'processing',
            'message': 'Request received and being processed asynchronously',
            'request_id': context.aws_request_id,
            'your_data': request_body
        })
    }
    
    # Async invoke worker

    lambda_client = boto3.client('lambda')
    lambda_client.invoke(
        FunctionName=os.environ['WORKER_FUNCTION_NAME'],
        InvocationType='Event',
        Payload=json.dumps({
            'original_request': request_body,
            'api_request_id': context.aws_request_id,
            'received_headers': event.get('headers', {})
        })
    )

    return response
