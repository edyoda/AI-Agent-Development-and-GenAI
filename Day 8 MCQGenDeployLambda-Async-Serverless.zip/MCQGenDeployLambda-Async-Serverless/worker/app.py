import urllib3
import time
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from langchain.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain_core.runnables import RunnablePassthrough
from typing import List, Dict
import json
import re,os


class MCQGeneratorAgent:
    def __init__(self, api_key: str, model_name: str = "gpt-3.5-turbo-instruct"):
        """
        Initialize the MCQ Generator Agent with an LLM.
        
        Args:
            api_key: API key for the LLM provider
            model_name: Name of the LLM model to use
        """
        self.llm = OpenAI(
            openai_api_key=api_key, 
            model=model_name, 
            temperature=0.7,
            max_tokens=2000
        )
        
        # Define the prompt template for MCQ generation
        self.mcq_prompt_template = PromptTemplate(
            input_variables=["topic", "subtopics", "num_questions", "difficulty"],
            template="""
            You are an expert MCQ generator for industry professionals and create the most useful scenario based MCQ. Create multiple choice questions based on:
            Topic: {topic}
            Subtopics: {subtopics}
            
            Generate exactly {num_questions} MCQs of {difficulty} difficulty. Follow these rules STRICTLY:
            
            FORMAT FOR EACH QUESTION:
            1. [Question number]. [Question text]
            a. [Option a]
            b. [Option b]
            c. [Option c]
            d. [Option d]
            (Correct) [Correct option letter]. [Correct option text]
            Explanation: [Brief explanation]
            
            IMPORTANT:
            - Maintain this exact format for every question
            - Don't include any additional text before or after questions
            - Number questions sequentially starting with 1
            - Mark the correct answer with (Correct)
            - Always include the Explanation: line
            - Use consistent formatting throughout
            
            Begin now:
            """
        )
        
        # Create the chain using the new syntax
        self.mcq_chain = (
            RunnablePassthrough.assign()
            | self.mcq_prompt_template
            | self.llm
        )
    
    def generate_mcqs(
        self, 
        topic: str, 
        subtopics: List[str], 
        num_questions: int = 5, 
        difficulty: str = "medium"
    ) -> List[Dict]:
        """
        Generate multiple choice questions based on the given topic and subtopics.
        """
        # Join subtopics into a comma-separated string
        subtopics_str = ", ".join(subtopics)
        
        # Generate the MCQs
        response = self.mcq_chain.invoke({
            "topic": topic,
            "subtopics": subtopics_str,
            "num_questions": num_questions,
            "difficulty": difficulty
        })
        
        return response

http = urllib3.PoolManager()

def lambda_handler(event, context):
    print("Hello World! Processing event:", event)


    mcq_agent = MCQGeneratorAgent(os.getenv("OPENAI_API_KEY"))

    quiz_data = event['original_request']

    # Define your topic and subtopics
    topic = quiz_data.get('topic')
    subtopics = quiz_data.get('sub-topics')

    print(f"Starting MCQ generation...{topic}, {subtopics}")
    response = mcq_agent.generate_mcqs(
        topic=topic,
        subtopics=subtopics,
        num_questions=10,
        difficulty="hard"
    )
    
    result = {
        'status': 'success',
        'message': response,
        'quiz_meta_id': quiz_data.get('quiz_meta_id'),
        'original_event': event,
        'lambda_request_id': context.aws_request_id,
        'timestamp': int(time.time())
    }
    
    # Send to webhook
    try:
        response = http.request(
            'POST',
            os.getenv("WEBHOOK_URL"),
            body=json.dumps(result),
            headers={'Content-Type': 'application/json'}
        )
        print(f"Webhook notification sent. Status: {response.status}")
    except Exception as e:
        print(f"Webhook failed: {str(e)}")
        raise
    
    return result
