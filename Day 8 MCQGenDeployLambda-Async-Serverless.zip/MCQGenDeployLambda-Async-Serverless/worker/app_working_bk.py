import json
import os
import urllib3
import time
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage



http = urllib3.PoolManager()

def lambda_handler(event, context):
    print("Hello World! Processing event:", event)
    print(context)
    # Initialize the OpenAI Chat model (GPT-3.5 or GPT-4)
    llm = ChatOpenAI(model="gpt-3.5-turbo",openai_api_key=os.getenv("OPENAI_API_KEY"))

    # Create a simple message
    messages = [HumanMessage(content="Hello, world! I am here to make this world a better place")]

    # Get a response (using invoke() instead of direct call)
    response = llm.invoke(messages)

    # Print the response
    print(response.content)
    
    result = {
        'status': 'success',
        'message': 'Hello Again' + str(response.content),
        'original_event': event,
        'lambda_request_id': context.aws_request_id,
        'timestamp': int(time.time())
    }
    
    # Send to webhook
    try:
        response = http.request(
            'POST',
            'http://13.200.116.100:8000/api/v1/studycontentgen/callfromlambda/',
            body=json.dumps(result),
            headers={'Content-Type': 'application/json'}
        )
        print(f"Webhook notification sent. Status: {response.status}")
    except Exception as e:
        print(f"Webhook failed: {str(e)}")
        raise
    
    return result
