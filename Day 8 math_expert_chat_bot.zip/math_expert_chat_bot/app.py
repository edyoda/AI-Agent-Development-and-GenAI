from flask import Flask, render_template, request, jsonify
import autogen
import os

app = Flask(__name__)

# Initialize AutoGen components
system_message = """You are a mathematics expert with specialization in calculus.
Follow these principles in your responses:
1. Break down complex problems into steps
2. Show your reasoning explicitly
3. Verify your answers with alternative methods when possible
4. Explain concepts using intuitive analogies
5. Highlight common misconceptions to avoid"""

config_list = [
    {
        "model": "gpt-4",
        "api_key": os.getenv("OPENAI_API_KEY"),
    }
]

math_expert = autogen.AssistantAgent(
    name="MathExpert",
    system_message=system_message,
    llm_config={
        "config_list": config_list,
        "temperature": 0.2,
    }
)

user_proxy = autogen.UserProxyAgent(
    name="Student",
    human_input_mode="NEVER",
    max_consecutive_auto_reply=1,
    code_execution_config=False,
    is_termination_msg=lambda x: True  # Always terminate after one response
)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    try:
        user_message = request.json["message"]
        
        # Reset agents for clean conversation
        math_expert.reset()
        user_proxy.reset()
        
        # Start chat and collect responses
        responses = []
        user_proxy.register_reply(
            [autogen.Agent, None],
            reply_func=lambda recipient, messages, sender, config: (
                responses.append(messages[-1]["content"]),
                (True, None)
            )[1]
        )
        
        user_proxy.initiate_chat(math_expert, message=user_message, clear_history=True)
        
        if responses:
            return jsonify({"response": responses[-1]})
        else:
            return jsonify({"response": "Sorry, I couldn't generate a response."})
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
